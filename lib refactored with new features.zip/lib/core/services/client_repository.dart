import 'package:lubrication_indicator/core/models/client_model.dart';
import 'package:lubrication_indicator/core/services/database_mode_service.dart';
import 'package:lubrication_indicator/core/utils/hash_util.dart';

class ClientRepository {
  final _db = DatabaseModeService.ref();
  static const _path = 'clients';
  String _toDbKey(String name) {
    final s = name.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_');
    return s.replaceAll(RegExp(r'^_+|_+$'), '');
  }

  Map<String, dynamic>? _safeMap(dynamic value) {
    if (value is! Map) return null;
    try {
      return Map<String, dynamic>.from(
        (value as Map).map((k, v) => MapEntry(k.toString(), v)),
      );
    } catch (_) {
      return null;
    }
  }

  Stream<List<ClientModel>> watchClients() {
    return _db.child(_path).onValue.map((event) {
      final map = _safeMap(event.snapshot.value);
      if (map == null) return <ClientModel>[];
      return map.values
          .where((e) => e is Map)
          .map((e) => ClientModel.fromMap(Map<String, dynamic>.from(e as Map)))
          .where((c) => c.isActive)
          .toList();
    });
  }

  Future<List<ClientModel>> getAllClients() async {
    final snap = await _db.child(_path).get();
    final map = _safeMap(snap.value);
    if (map == null) return <ClientModel>[];
    return map.values
        .where((e) => e is Map)
        .map((e) => ClientModel.fromMap(Map<String, dynamic>.from(e as Map)))
        .where((c) => c.isActive)
        .toList();
  }

  Future<ClientModel> createClient({
    required String name,
    String description = '',
  }) async {
    final id = HashUtil.generateId();
    final dbKey = _toDbKey(name);
    final client = ClientModel(
      id: id,
      name: name.trim(),
      dbKey: dbKey,
      description: description.trim(),
      rootFolderId: null,
      createdAt: DateTime.now().toIso8601String(),
    );
    await _db.child('$_path/$id').set(client.toMap());
    await _db.child('$dbKey/meta').set({
      'client_id': id,
      'name': client.name,
      'description': client.description,
      'created_at': client.createdAt,
    });
    return client;
  }
}

part of '../property_builder_page.dart';

class SessionParamStore {
  static Database? _db;

  static Future<Database> _open() async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    _db = await openDatabase(
      p.join(dbPath, 'session_params.db'),
      version: 1,
      onCreate: (db, _) => db.execute('''
        CREATE TABLE session_params (
          id          TEXT PRIMARY KEY,
          session_id  TEXT NOT NULL,
          label       TEXT NOT NULL,
          type        TEXT NOT NULL,
          left_label  TEXT,
          right_label TEXT
        )
      '''),
    );
    return _db!;
  }

  static Future<void> upsert(
      String sessionId, Map<String, dynamic> param) async {
    final db = await _open();
    await db.insert(
      'session_params',
      {
        'id': param['id']?.toString() ?? '',
        'session_id': sessionId,
        'label': param['label']?.toString() ?? '',
        'type': param['type']?.toString() ?? '',
        'left_label': param['left_label']?.toString(),
        'right_label': param['right_label']?.toString(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  static Future<List<Map<String, dynamic>>> getAll(
      String sessionId, String excludeId) async {
    final db = await _open();
    final rows = await db.query(
      'session_params',
      where: 'session_id = ? AND id != ?',
      whereArgs: [sessionId, excludeId],
    );
    return rows;
  }

  static Future<void> clearSession(String sessionId) async {
    final db = await _open();
    await db.delete('session_params',
        where: 'session_id = ?', whereArgs: [sessionId]);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PropertyBuilderPage
// ─────────────────────────────────────────────────────────────────────────────
